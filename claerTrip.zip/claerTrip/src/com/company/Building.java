package com.company;


public class Building {
    Floor floor;
    public Building(Floor floor){
        this.floor = floor;
    }
    public Floor getFloors(){
        return floor;
    }
}
